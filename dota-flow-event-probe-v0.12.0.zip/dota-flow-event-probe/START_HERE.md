# Start here — Dota Flow 0.12

## 1. Verify the project

```bash
npm test
npm run check
npm run preflight
npm run coach
npm run replay
npm run diagnose
npm run live
npm run overlay
npm run roles
npm run role-context
npm run manual-context
npm run validate:match -- --release
npm run validate:suite
```

The suite covers all 127 heroes, 32 detailed carry/core profiles, canonical normalization, live diagnostics, Macro/Power Spike/Role engines, manual-context replay and the Coach Suite.

## 2. Open Coach Center

```bash
npm run mock
```

Open `http://127.0.0.1:4173/coach`.

Use the three modes:

- **Pre-game** — draft briefing, adaptive build, counter-items and optional public scouting;
- **Live** — event timers and voice priorities;
- **Post-game** — Flow Performance Index and multi-match progress.

## 3. Open Live Monitor

Open `http://127.0.0.1:4173/live`.

The Live Monitor combines macro advice, role task, role-context quality, Coach timers, adaptive build and counter-items. Roshan and Aegis buttons create replayable `coach-event` envelopes.

## 4. Manual context

The **MANUAL CONTEXT** panel confirms lane state, route safety, Bottle rune, Wisdom contest, side-lane target, carry threat and support camp availability. Every confirmation remains marked `MANUAL` and expires under the existing safety rules.

## 5. First-match readiness

Run `npm run preflight`, then perform the first test on Windows in a bot lobby. Start capture before GEP registration and keep the application running into a second lobby so match rotation can be validated.

## 6. Safety boundary

Dota Flow does not read process memory, reveal hidden enemies, press abilities or control the hero. External scouting uses public data only. Missing information remains `UNAVAILABLE` instead of being invented.
