# Dota Flow — Coach Suite 0.12

Dota Flow is an explainable live decision assistant for Dota 2. Overwolf GEP supplies permitted telemetry, the canonical pipeline builds a normalized game state, and the Macro, Power Spike, Role and Coach engines produce advice without controlling the hero.

Version 0.12 adds a complete **pre-game → in-game → post-game → long-term progress** coaching loop inspired by useful product patterns in Dota Coach and Mobalytics, but implemented with original code, UI and decision models.

## Current coverage

- **127 heroes recognized**;
- **32 DETAILED carry/core profiles**;
- **95 conservative BASELINE profiles**;
- Macro actions: `FARM`, `CONNECT`, `FIGHT`, `PRESSURE`, `RESET`, `OBJECTIVE`;
- role tasks for carry, mid, offlane, position 4 and position 5;
- live diagnostics, JSONL recording, validation, overlay and multi-match sessions;
- manual context for visible information that GEP does not provide;
- Coach Suite with adaptive builds, counter-items, timers, voice cues, scouting and performance progress.

## Coach Suite

### Before the match

- draft threats and allied strengths;
- adaptive selection between calibrated build plans;
- counter-item recommendations with explanations;
- optional public OpenDota scouting by SteamID64.

### During the match

- Power, Water and Wisdom Rune reminders;
- day/night schedule;
- manual Roshan, Aegis, Glyph, buyback and ultimate timers;
- priority voice coaching;
- live macro, role task, power spike and adaptive build in one snapshot.

### After the match

- Flow Performance Index;
- seven performance dimensions;
- prioritized improvements;
- trend and focus areas across up to 50 locally stored reports in Coach Center.

## Run

Requires Node.js 20+.

```bash
npm test
npm run check
npm run preflight
npm run coach
npm run replay
npm run diagnose
npm run live
npm run overlay
npm run roles
npm run role-context
npm run manual-context
npm run validate:match
npm run validate:suite
npm run mock
```

Local pages:

```text
http://127.0.0.1:4173
http://127.0.0.1:4173/coach
http://127.0.0.1:4173/diagnostics
http://127.0.0.1:4173/live
http://127.0.0.1:4173/overlay
http://127.0.0.1:4173/validation
```

## First real test

1. Run `npm run preflight`.
2. On Windows, install dependencies in `apps/overwolf-electron`.
3. Add `-gamestateintegration` to Dota 2 launch options.
4. Start Dota Flow before a bot lobby.
5. Keep capture running through a complete match and a second lobby.
6. Use manual and coach controls only for facts visible to the player.
7. Validate the complete capture directory.

See `docs/COACH_SUITE_IMPLEMENTED.md`, `docs/MANUAL_CONTEXT_FIRST_MATCH.md` and `docs/FIRST_LIVE_TEST.md`.
