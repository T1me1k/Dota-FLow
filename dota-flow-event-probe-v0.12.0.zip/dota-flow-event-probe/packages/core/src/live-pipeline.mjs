import { createInitialGameState } from './game-state.mjs';
import { StableDecisionCoordinator } from './decision-engine.mjs';
import { StableRoleDecisionCoordinator } from './role-engine.mjs';
import { applyGameEvent } from './event-reducer.mjs';
import { GAME_EVENT_TYPES } from './game-events.mjs';
import { normalizeGameState } from './game-state-normalizer.mjs';
import { buildCoachSuiteSnapshot } from './coach-suite.mjs';

function historyEntry(state, previousDecision, decision, event) {
  return {
    gameTimeSec: state.gameTimeSec,
    previousAction: previousDecision?.action ?? null,
    action: decision.action,
    confidence: decision.confidence,
    reasons: [...decision.reasons],
    triggerEventType: event.type,
    powerStatus: decision.powerState?.status ?? null
  };
}

function roleHistoryEntry(state, previousDecision, decision, event) {
  return {
    gameTimeSec: state.gameTimeSec,
    role: decision.role,
    previousAction: previousDecision?.action ?? null,
    action: decision.action,
    confidence: decision.confidence,
    reasons: [...decision.reasons],
    target: decision.target ?? null,
    triggerEventType: event.type
  };
}

export class GameEventPipeline {
  constructor({ initialState, coordinatorOptions } = {}) {
    const base = createInitialGameState(initialState ?? {});
    this.state = normalizeGameState(base, base, { eventType: 'PIPELINE_INITIALIZED' });
    this.coordinatorOptions = coordinatorOptions ?? {};
    this.coordinator = new StableDecisionCoordinator(this.coordinatorOptions);
    this.roleCoordinator = new StableRoleDecisionCoordinator(this.coordinatorOptions?.role ?? {});
    this.decision = this.coordinator.update(this.state);
    this.roleDecision = this.roleCoordinator.update(this.state);
    this.decisionHistory = [];
    this.roleDecisionHistory = [];
    this.eventCount = 0;
    this.coach = buildCoachSuiteSnapshot(this.snapshotBase());
  }

  dispatch(event) {
    let previousDecision = this.decision;
    let previousRoleDecision = this.roleDecision;
    if (event?.type === GAME_EVENT_TYPES.MATCH_STARTED) {
      this.coordinator = new StableDecisionCoordinator(this.coordinatorOptions);
      this.roleCoordinator = new StableRoleDecisionCoordinator(this.coordinatorOptions?.role ?? {});
      this.decisionHistory = [];
      this.roleDecisionHistory = [];
      this.eventCount = 0;
      previousDecision = null;
      previousRoleDecision = null;
    }

    this.state = applyGameEvent(this.state, event);
    this.decision = this.coordinator.update(this.state);
    this.roleDecision = this.roleCoordinator.update(this.state);
    this.eventCount += 1;

    if (this.decision.action !== previousDecision?.action) {
      this.decisionHistory.push(historyEntry(this.state, previousDecision, this.decision, event));
    }
    if (this.roleDecision.action !== previousRoleDecision?.action || this.roleDecision.role !== previousRoleDecision?.role) {
      this.roleDecisionHistory.push(roleHistoryEntry(this.state, previousRoleDecision, this.roleDecision, event));
    }

    this.coach = buildCoachSuiteSnapshot(this.snapshotBase());
    return this.snapshot();
  }

  dispatchMany(events = []) {
    let result = this.snapshot();
    for (const event of events) result = this.dispatch(event);
    return result;
  }

  snapshotBase() {
    return {
      state: this.state,
      decision: this.decision,
      roleDecision: this.roleDecision,
      decisionHistory: [...this.decisionHistory],
      roleDecisionHistory: [...this.roleDecisionHistory],
      eventCount: this.eventCount
    };
  }

  snapshot() {
    return {
      ...this.snapshotBase(),
      coach: this.coach
    };
  }
}

export function createGameEventPipeline(options) {
  return new GameEventPipeline(options);
}
